#!/bin/bash
# Start Laravel server op poort 8080
php /home/site/wwwroot/artisan serve --host=0.0.0.0 --port=8181
