# title

## 10-10
* vandaag hebben we alles opgezet voor ons start project

##  14-10
* ik heb mijn usersturies gemaakt samen met mijn ERD

## 15-10
* ik heb vandaag de lessen gekeken van de Laracast, en gewerkt met de components en Blade templates
* en eigen database opgezet voor nu met dummy data.

## 17-10
* we hebben in de les één op veel relaties en veel op veel relaties aan gemaakt met onze eigen eindproject.
* en een create en index gemaakt voor je eigen project

## 21-10
* heb zelf zelfstandig de les doorgenomen vanwege ik ziek was en heb een filter knop toegevoegt aan mijn project om te filteren op genres

## 22-10
* vandaag ben ik verder gegaan met de crud, had de create al af maar nog niet de edit maar die werkt nu we
* De user_id is nu ook gekoppeld aan de account dus ik kan de namen zien van wie de posts heeft gemaakt
* heb ook nog de edit afgemaakt en de delete. heb ook bij edit de knop alleen actief gezet als je dezelfde user_id hebt zodat je niet van iemand ander kan editen

## 24-10
* ik ben vandaag bezig geweest met de admin rol en dat hij alles kan bewerken.
* heb de search bar gemaakt en de show (details) page gemaakt
* en heb een beetje meer vormgeving aan de site gegeven.

## 25-10
* heb een navbar gemaakt zodat ik beter naar verschillende pages kan
* heb voor de create page een veiligheid gemaakt zodat als iemand zonder account er op wilt word hij door gestuurd naar de login als hij de url aanpast want heb de knop gewoon uitgezet voor mensen zonder account
* een comment sectie gemaakt met een controller, model en de view staat in show en natuurlijk een tabel in de database
* alle onnodige dingen die ik met opdrachte heb gemaakt in de les verwijderd zodat ik beter overzicht heb

## 26-10
* ik heb meer aan de opmaak gewerkt
* een dit knop en verwijder knop gemaakt voor de comment section
* een logo gemaakt
* en een captions aangemaakt voor de gebruiker

## 29-10
* layout gemaakt voor navbar
* profiel wachtwoord aanpassen
* oneindig create klik aangepast

## 30-10
* profiel is uitgewerkt met eigen albums
* bezig met de aan en knop met admin voor albums
* geprobeerd met Render website live zetten is helaas niet gelukt

## 31-10
* admin dashboard is klaar en werkt met aan en uit knop voor albums
* admin dashboard veilig gemaakt voor mensen die de url proberen te plakken
* deeplinken is ook klaar, heb de gebruiker 3 post moeten doen voordat hij een reactie mag plaatsen
* oneindig create klik aangepast bij reacties

